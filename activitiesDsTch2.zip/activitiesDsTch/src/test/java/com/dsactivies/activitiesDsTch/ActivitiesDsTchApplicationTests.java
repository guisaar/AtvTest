package com.dsactivies.activitiesDsTch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActivitiesDsTchApplicationTests {

	@Test
	void contextLoads() {
	}

}
