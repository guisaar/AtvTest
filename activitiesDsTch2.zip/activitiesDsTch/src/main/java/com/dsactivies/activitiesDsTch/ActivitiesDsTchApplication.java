package com.dsactivies.activitiesDsTch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActivitiesDsTchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActivitiesDsTchApplication.class, args);
	}

}
