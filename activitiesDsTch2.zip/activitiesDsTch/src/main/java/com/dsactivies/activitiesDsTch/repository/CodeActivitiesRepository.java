package com.dsactivies.activitiesDsTch.repository;
import com.dsactivies.activitiesDsTch.models.event;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CodeActivitiesRepository extends JpaRepository<event, Long> {

}
