package com.dsactivies.activitiesDsTch.controllers;

import com.dsactivies.activitiesDsTch.models.event;
import com.dsactivies.activitiesDsTch.repository.CodeActivitiesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EventController {

    @Autowired
    private CodeActivitiesRepository er;
    @RequestMapping(value="/registerEvent", method = RequestMethod.GET)
    public String form() {
        return "event/formEvent";
    }
    @RequestMapping(value="/registerEvent", method = RequestMethod.POST)
    public String form(event evento) {
        er.save(evento);
        return "redirect:/registerEvent";
    }
    @RequestMapping("/event")
    public ModelAndView listEvent(){
        ModelAndView mv = new ModelAndView("index");
        Iterable<event> events = er.findAll();
        mv.addObject("events",events);
        return mv;
    }

}